#!/system/bin/sh
/data/powercat/powercat.sh  com.xd.powercatsence  MainActivity  
sleep 3
echo "Test activity start secceed..."
