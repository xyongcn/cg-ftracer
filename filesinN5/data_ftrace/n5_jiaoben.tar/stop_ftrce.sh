#!/system/bin/sh
echo nop > current_tracer                                
echo 0 > tracing_on


