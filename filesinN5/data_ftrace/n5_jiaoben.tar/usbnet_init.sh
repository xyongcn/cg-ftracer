#!/system/bin/sh
am start -n com.example.androidtestusbtethering/com.example.androidtestusbtethering.MainActivity


