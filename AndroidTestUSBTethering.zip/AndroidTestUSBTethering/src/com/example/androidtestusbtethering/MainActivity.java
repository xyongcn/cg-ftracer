package com.example.androidtestusbtethering;

import java.io.DataOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import android.net.ConnectivityManager;
import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.hardware.usb.UsbManager;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity {
	private Button button;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		Log.i("UsbTethering","Detecting tetherable usb interface.");
		String[] available = null;
		Object connectivityServiceObject = getSystemService(CONNECTIVITY_SERVICE);
		ConnectivityManager connMgr = (ConnectivityManager)connectivityServiceObject;
		Method[] wmMethods = connMgr.getClass().getDeclaredMethods();
		Method method = null;
		for(Method getMethod: wmMethods)
		{
		    if(getMethod.getName().equals("setUsbTethering"))
		    {
		        
//		            available = (String[]) getMethod.invoke(connMgr);
		        	try {
						getMethod.invoke(connMgr,true);
					} catch (IllegalArgumentException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (IllegalAccessException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (InvocationTargetException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						e.getCause().printStackTrace();
					}
		            break;
		        
		    }
		}
		
		
		button = (Button)this.findViewById(R.id.button1);
		button.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
//				
//				String apkRoot="chmod 777 "+getPackageCodePath();  
//		        RootCommand(apkRoot); 
			    
//				Object obj = getSystemService(Context.CONNECTIVITY_SERVICE);
//                for (Method m : obj.getClass().getDeclaredMethods()) {
//
//                    if (m.getName().equals("tether")) {
//                    	m.setAccessible(true);
//                        try {
//                            m.invoke(obj, "rndis");//rndis0
//                        } catch (Exception e) {
//                            // TODO Auto-generated catch block
//                            e.printStackTrace();
//                        } 
//                    }
//                }
                

                
//				ConnectivityManager cm =  
//			            (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);  
//			        if (cm.setUsbTethering(true) != ConnectivityManager.TETHER_ERROR_NO_ERROR ){  
//			                
//			              System. out.println("usb tethering set failed !" );  
//			        }
				
			    // DETECT INTERFACE NAME
				Log.i("UsbTethering","Detecting tetherable usb interface.");
				String[] available = null;
				Object connectivityServiceObject = getSystemService(CONNECTIVITY_SERVICE);
				ConnectivityManager connMgr = (ConnectivityManager)connectivityServiceObject;
				Method[] wmMethods = connMgr.getClass().getDeclaredMethods();
				Method method = null;
				for(Method getMethod: wmMethods)
				{
				    if(getMethod.getName().equals("setUsbTethering"))
				    {
				        
//				            available = (String[]) getMethod.invoke(connMgr);
				        	try {
								getMethod.invoke(connMgr,true);
							} catch (IllegalArgumentException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} catch (IllegalAccessException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} catch (InvocationTargetException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
								e.getCause().printStackTrace();
							}
				            break;
				        
				    }
				}
				// DETECT INTERFACE NAME

//				String desiredString = "open";
//				if(available.length > 0)
//				{       
//					for (Method m : connectivityServiceObject.getClass().getDeclaredMethods()) {
//
//	                    if (m.getName().equals("tether")) {
//	                    	for(String interfaceName : available)
//	    				    {
//	    				        Log.i("UsbTethering", "Detected " + String.valueOf(available.length) + " tetherable usb interfaces.");
//	    				        Log.i("UsbTethering", "Trying to " + desiredString + " UsbTethering on interface " + interfaceName + "...");
//	    				        Integer returnCode = -1;
//	    						try {
//	    							returnCode = (Integer)m.invoke(connectivityServiceObject, interfaceName);
//	    						} catch (Exception e) {
//	    							// TODO Auto-generated catch block
//	    							e.printStackTrace();
//	    						}
//	    				        if(returnCode == 0)
//	    				        {
//	    				            Log.i("UsbTethering", "UsbTethering " + desiredString + "d.");
//	    				            
//	    				        }
//	    				        else
//	    				        {
//	    				            Log.w("UsbTethering", "Failed to " + desiredString + "Usb Tethering. ReturnCode of method " + m.getName() + ": " + String.valueOf(returnCode));
//	    				        }
//	    				    }
//	                    }
//	                }
//				    
//				}
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	
	/** 
     * 应用程序运行命令获取 Root权限，设备必须已破解(获得ROOT权限) 
     * @param command 命令：String apkRoot="chmod 777 "+getPackageCodePath(); RootCommand(apkRoot); 
     * @return 应用程序是/否获取Root权限 
     */  
    public static boolean RootCommand(String command)  
    {  
        Process process = null;  
        DataOutputStream os = null;  
        try  
        {  
            process = Runtime.getRuntime().exec("su");  
            os = new DataOutputStream(process.getOutputStream());  
            os.writeBytes(command + "\n");  
            os.writeBytes("exit\n");  
            os.flush();  
            process.waitFor();  
        } catch (Exception e)  
        {  
            Log.d("*** DEBUG ***", "ROOT REE" + e.getMessage());  
            return false;  
        } finally  
        {  
            try  
            {  
                if (os != null)  
                {  
                    os.close();  
                }  
                process.destroy();  
            } catch (Exception e)  
            {  
            }  
        }  
        Log.d("*** DEBUG ***", "Root SUC ");  
        return true;  
    }  

}
